package com.example.android.bicyclequizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
    }

    /**
     * This method is called when the show score button is clicked and it checks if the
     * the right answer was checked.
     */

    public void showScore (View view) {


        RadioButton nineteenRadioButton = findViewById(R.id.answer_fourth_question_1);
        boolean isNineteen = nineteenRadioButton.isChecked();

        RadioButton woodRadioButton = findViewById(R.id.answer_second_question_2);
        boolean isWood = woodRadioButton.isChecked();

        RadioButton a500RadioButton = findViewById(R.id.answer_second_question_3);
        boolean isA500 = a500RadioButton.isChecked();

        CheckBox wellCheckBox = findViewById(R.id.answer_first_question_4);
        boolean  isWell = wellCheckBox.isChecked();

        CheckBox stressCheckBox = findViewById(R.id.answer_second_question_4);
        boolean  isStress = stressCheckBox.isChecked();

        CheckBox priorityCheckBox = findViewById(R.id.answer_third_question_4);
        boolean  isPriority = priorityCheckBox.isChecked();

        CheckBox fitnessCheckBox = findViewById(R.id.answer_fourth_question_4);
        boolean  isFitness = fitnessCheckBox.isChecked();

        CheckBox trafficCheckBox = findViewById(R.id.answer_fifth_question_4);
        boolean  isTraffic = trafficCheckBox.isChecked();

        EditText wheelsEditText = findViewById(R.id.answer_first_question_5);
        String userFirstAnswer = wheelsEditText.getText().toString();

        EditText frameEditText = findViewById(R.id.answer_second_question_5);
        String userSecondAnswer = frameEditText.getText().toString();


        int score = calculateScore(isNineteen, isWood, isA500, isWell, isStress, isPriority, isFitness,isTraffic,
                userFirstAnswer, userSecondAnswer);
        displayScore(score);
    }

    /**
     * This method is calculating final score for quiz
     */

    private int calculateScore(boolean addOnePointForQ1, boolean addOnePointForQ2,
                               boolean addOnePointForQ3, boolean firstCorrectCheckForQ4,
                               boolean secondCorrectCheckForQ4,
                               boolean doNothingIfCheckForQ4,
                               boolean fourthCorrectCheckForQ4, boolean fifthCorrectCheckForQ4,
                               String userFirstAnswer,
                               String userSecondAnswer) {
        int initialResult = 0;

        if (addOnePointForQ1) {
            initialResult = initialResult + 1;
        }

        if (addOnePointForQ2) {
            initialResult = initialResult + 1;
        }
        if (addOnePointForQ3) {
            initialResult = initialResult + 1;
        }
        if (firstCorrectCheckForQ4 && secondCorrectCheckForQ4 && fourthCorrectCheckForQ4 && fifthCorrectCheckForQ4 && !doNothingIfCheckForQ4) {
            initialResult = initialResult + 1;
        }
        if (userFirstAnswer.equalsIgnoreCase("wheels" )) {
            if (userSecondAnswer.equalsIgnoreCase( "frame" )) {
                initialResult = initialResult + 1;
            }
        }
        if (userFirstAnswer.equalsIgnoreCase("wheel" )) {
            if (userSecondAnswer.equalsIgnoreCase( "frame" )) {
                initialResult = initialResult + 1;
            }
        }
        if (userFirstAnswer.equalsIgnoreCase("frame" )) {
            if (userSecondAnswer.equalsIgnoreCase( "wheels" )) {
                initialResult = initialResult + 1;
            }
        }
        if (userFirstAnswer.equalsIgnoreCase("frame" )) {
            if (userSecondAnswer.equalsIgnoreCase( "wheel" )) {
                initialResult = initialResult + 1;
            }
        }
        return initialResult;
    }

    /**
     * This method will display final result
     */

    private void displayScore(int scoreForPlayer){
        TextView scoreAfterQuiz = findViewById(R.id.final_score);
        if (scoreForPlayer == 5){
            Toast.makeText(getApplicationContext(),
                    "All answers are correct. Have fun riding a bike. ", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(getApplicationContext(),
                    "Thank you! Your score is: " + scoreForPlayer , Toast.LENGTH_LONG).show();
        }
        scoreAfterQuiz.setText("" + scoreForPlayer);
    }

}
